SciLor's grooveshark(tm).com Downloader v0.4.9.3a
                            i.
                            .7.
                           .. :v
                          c:  .X
                           i.::
                             :
                            ..i..
                           #MMMMM
                           QM  AM
                           9M  zM
                           6M  AM
                           2M  2MX#MM@1.
                           OM  tMMMMMMMMMM;
                      .X#MMMM  ;MMMMMMMMMMMMv
                  cEMMMMMMMMMU7@MMMMMMMMMMMMM@
            .n@MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
           MMMMMMMM@@#$BWWB#@@#$WWWQQQWWWWB#@MM.
           MM                                ;M.
           $M                                EM
           WMO$@@@@@@@@@@@@@@@@@@@@@@@@@@@@#OMM
           #M                                cM
           QM         Another Cake by        tM
           MM              SciLor            CMO
        .MMMM                                oMMMt
       1MO 6MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM iMM
      .M1  BM     For all Portal Lovers!     vM  ,Mt
      1M   @M............................... WM   M6
       MM  .A8OQWWWWWWWWWWWWWWWWWWWWWWWWWWWOAz2  #M
        MM                                      MM.
         @MMY                                vMME
           UMMMbi                        i8MMMt
              C@MMMMMbt;;i.......i;XQMMMMMMt
                   ;ZMMMMMMMMMMMMMMM@A;.

ReadMe

You will need the .NET Framework 4.0

SciLor's grooveshark(tm).com Downloader is a tool for downloading and playing music from grooveshark(tm).com.
I am not responsible for any violations to the Terms of Use of grooveshark(tm).com this tool may do. It is more or less a proove of concept. 

I am not related to grooveshark(tm).com in any way!

ToDo:

Additional:
If you create a file named "customIcon.ico" in the SciLor's grooveshark(tm).com Downloader directory you can override the icon in the taskbar (Requested by a user)

Known Bugs:

If you like my hard work PLEASE DONATE! :)
http://www.scilor.com/donate.html

ChangeLog:

v0.4.9.3a(2012-03-14)
-New: Hebrew language
-Updated: Json Library
-Fix: Problems with some json errors when searching

-----------------------

v0.4.9.3(2012-03-13)
-New: Updater for GrooveFix.xml (Small updates)
-New: Auto language detection.
-Fix: Grooveshark(tm) changed again...
-Removed/Fix: Gema message with tor.

v0.4.9.2e(2012-02-29)
-Fix: Grooveshark(tm) changed :P

v0.4.9.2d(2012-02-22)
-Fix: Grooveshark(tm) made a little change again :P
-New: Hebrew language included (thank you omerbennun!)

v0.4.9.2c(2012-02-07)
-Fix: Grooveshark(tm) is funny, they changed something again ;)

v0.4.9.2b(2012-01-30)
-Fix: Delete Skipped Songs!

v0.4.9.2(2012-01-30)
-Update: Finnish translation (thank you babaz!)
-Fix: Downloading more than a couple of songs shouldn't make any problem ;)

v0.4.9.1(2012-01-27)
-Enhancement: Save some bandwidth (Api)
-Fix: Another change on grooveshark(tm) - You may be blocked after some songs!

v0.4.9u(2012-01-21)
-Fix: Seemed to stop downloading after 5 songs ;)
-Enhancement: Don't start downloading songs when skipping.

v0.4.9t(2012-01-21)
-Enhancement: Fallback to the mobile version (again) is now fixed. Should work for germany fine again!

v0.4.9s(2012-01-20)
-Update: Portuguese language (thank you hugo_luiten)
-Enhancement: Now available from germany without the mobile version or tor. Full features for you!
-Enhancement: Some country api included again!

v0.4.9r(2012-01-19)
-Update: Portuguese language (thank you hugo_luiten)
-Update: Now use the mobile version of grooveshark(tm), if the normal version isn't available (Works without Tor in germany).
-Update: It is only asked for Tor, if the mobile version fails.
-Enhancement: Various new translatable strings.
-Fix: A problem that occours with long filenames and existing files.
-Fix: Crash when Tor installation is missing.

v0.4.9q(2012-01-19)
-Update: Portuguese language (thank you hugo_luiten)
-Fix: A problem that may caused much high cpu usage while doing nothing
-Fix: Automatically ask for running the Downloader + Tor if the user is from Germany (+commandline switch & .bat file).
-Fix: Show error for germans
-Fix: Buggy proxy support
-Fix: "Start reconnecting" Should be translated at app start, too
-Fix: Various things now translatable.

v0.4.9p(2012-01-08)
-New: Loading Bitrate for a song (Right mouse)
-New: Romanian language (thanks you speednsx)
-New: Portuguese-Brazil language (thanks you szanini)
-Update: Portuguese language (thanks you hugo_luiten)
-Fix: PathTooLongException fixed, now we can have longer filenames :)
-Fix: Some System.NullReferenceException Errors that occoured for some users
-Fix: No search results for some users
-Fix: A too small download queue button for other language texts.
-Fix: Autocomplete working again

v0.4.9o(2012-01-03)
-Feature: Tray Icon to minimize to tray
-Feature: New commandline arguments for setting username/password and fetching the playlists
-Enhancement: Select first playlist after login automatically
-Change: Keep everything in the search box in commandline mode when working with playlists
-Fix: A possible problem with the search, that some users had.
-Fix: A crash on WinXP when not at 96dpi.
-Fix: A commandline bug (-add)

v0.4.9n(2011-11-17)
-Feature: Show length of some songs ;)
-Fix: Change on the excelent grooveshark(tm) webservice
-Fix: Aero Theme on XP

v0.4.9m(2011-08-31)
-Fix: Songname empty Problem
-Feature: Makes the Commandline arguments asynchronous so you can see whats happening
-Feature: Commandline "-playlistById <id>", "-add <number/all>"
-Feature: Dump Playlist login via enter-key

v0.4.9l(2011-08-09)
-Fix: Batch and Search - Autocomplete bug
-Feature: Command line: Try "-help"

v0.4.9k(2011-07-19)
-Fix: Change on the excelent grooveshark(tm) webservice
-Fix: Reappearing downloads that were already deleted.

v0.4.9j(2011-05-04)
-Fix: A bug resulting in problems with downloads. (Conversion from string "Begin fetching streamkey for " to type 'Double' is not valid)

v0.4.9i(2011-05-04)
-Feature: GridSplitter that allows to change the size of the Search/Download tables (forgot it on the last release).
-Feature: Filter search results.
-Feature: Debug mode with "-debug" as command line parameter

v0.4.9h(2011-04-26)
-Feature: Ignore certificates by creating a "nocert" file
-Feature: GridSplitter that allows to change the size of the Search/Download tables.
-Fix: Another change on the excelent grooveshark(tm) webservice
-Fix: Possible bugs when not in admin mode.
-Fix: A wrong caption of the download button.
-New: Facebook button

v0.4.9g(2011-03-13)
-Fix: Song Preview Fixed

v0.4.9f(2011-03-13)
-Feature: Open a song on grooveshark(tm) with right click on the song.
-Feature: Username/Password Proxy support(experimental), including a test button.
-Enhancement: Better Country handling (50 and more songs...).
-Enhancement: Better Skinhandling on missing elements.


v0.4.9e(2011-03-12)
-Enhancement: Various language file updates
-Feature: Get a playlist by its id
-Fix: A problem that occured on download of 50 or more songs
-Fix: Languagefile use of "tabConfigConnection".
-Fix: Ensure that the application is really closed.

v0.4.9d(2011-03-06)
-Fix: "Cowbell not found" error fixed, due to a change on the very nice grooveshark(tm).com service.

v0.4.9c(2011-02-19)
-Fix: A bug that may crash the app on chaning the language ('=' is an unexpected token. The expected token is ';'. Line 1, position 124.)

v0.4.9 Beta(2011-02-19)
-Feature: Italian, Turkish, Danish, Hungarian Translations :) Thank you all
-Feature: Autoconnect on Startup.
-Feature: Proxy (Settings).
(grpConfigConnection/grpProxy/lblProxy/txtProxy)

v0.4.8 Beta(2011-01-04)
-Enhancement: Faster inital connect :)
-Fix: Improved autoartistsearch (crashes/bugs)

v0.4.7 Beta(2011-01-04)
-Feature: Language Engine :), including some translations(catalan, french, german, germanbavarian, portuguese, spanish, swedish) Thanks fly out to all translators!
-Feature: Click on Search result marks/unmarks it
-Feature: Mark your results, right click and Select!
-Feature: Search Autocomplete :)
-Enhancement: Better resizing of the Controls to fit longer/shorter language strings ;)

v0.4.6 Beta(2010-12-22)
-Feature: Go to download directory(May have problems with long paths) under the "Extra" menu entry ("mniGoToDownloadDir" in the Skinfile!)
-Fix: Change on the grooveshark(tm).com Website made some problems ;)

v0.4.5 Beta(2010-12-15)
-Fix: Problems with loading Skin if starting from Shortcut(thanks fly out to anerathil)

v0.4.4 Beta(2010-12-12)
-Feature: Import Batch Search & Add from file (New button in the skin "btnImportBatch")
-Feature: Skip/Overwrite/Autorename existing files (New radiobuttons "rbtExistingSkip"/"rbtExistingOverwrite"/"rbtExistingAutoRename"
-Fix: Counting from one instead of zero (deleting)

v0.4.3 Beta(2010-12-03)
-Fix: Cowbell error fixed ;)

v0.4.2 Beta(2010-12-02)
-Feature: Right click any song to search for all songs having the same album or same artist :)
-Enhancement: Timeout set to 10 from 5 seconds
-Fix: Possible crash on Timeout on reconnect
-Fix: Broken downloadlists should be handled correctly now!

v0.4.1 Beta(2010-11-25)
-Feature: Recover Downloadlist on Startup(May need admin rights!)
-Enhancement: Most things are now working in an extra thread (Downloading etc.) to make the app more responsible
-Fix: Icon was broken
-Fix: Sorting of the download list would cause errors, now it's disabled

v0.4.0 Beta(2010-11-23)
-New: .Net Framework 4.0 should be needed (untested)
-New: Completely new WPF based Window that can be skinned by your needs if you are able to write in XAML
-Enhancement: Auto reconnect on token error. If it fails 2 times in a row an error is thrown

v0.3.9 Beta(2010-10-21)
-Fix: Wrong sorted playlists fixed
-Fix: Possible crash on loading playlists.

v0.3.8 Beta(2010-10-21)
-Enhancement: Auto check for updates on startup
-Feature: Download your playlists from grooveshark(tm).com :)

v0.3.7 Beta(2010-10-12)
-Enhancement: Select All etc.
-Feature: Batch Search & Add.
-Feature: Custom Icon via "customIcon.ico"

v0.3.6 Beta(2010-09-16)
-Enhancement: Experimental reconnect dialog on invalid token
-Enhancement: Reconnect Button

v0.3.5 Beta(2010-09-07)
-Enhancement: misterious "privacy" ;)
-Fix: New revision

v0.3.4 Beta(2010-07-10)
-Enhancement: Better error handling (especially on wrong incoming data)
-New: Uncheck all checked search results after adding them to the download list (Can be disabled in the settings)
-Fix: Filename handling now allows directories again.

v0.3.3 Beta(2010-07-06)
-Enhancement: Better error handling
-Feature: Check by click on entry
-Feature: Immediately download abortion
-New: Nice icon
-Fix: Config.xml and missing administration rights
-Fix: Real use of repaired filenames

v0.3.2 Beta(2010-06-26)
-New: Settings dialog, including selection of the download directory and the song renaming patterns
-Feature: Popular song search
-Feature: Delete songs of the download list with a click
-Enhancement: Better error handling and Debug log
-Fix: Enter key to start search

v0.3.1 Beta(2010-06-23)
-Quickfix: Crash on any search...

v0.3.1 Alpha(2010-06-23)
-Enhancement: New revision, country fix included ;)
-Fix: Crashes on illegal file characters in track names
-Fix: Language specific characters fixed (letters with circumflexes, points, umlauts etc.)

v0.3 Alpha(2010-05-09)
-Enhancement: New API and new form.

v0.2.3 Beta(2010-04-15)
-Enhancement: GrooveFix.xml for easy fix for token and client problems.
-Fix: New clientRevision on grooveshark(tm).com
-Fix: New staticRandomizer on grooveshark(tm).com

v0.2.2 Beta(2010-03-24)
-Fix: I fixed another revision change :)
-Feature: SciLor's Update Checker included ;)

v0.2.1 Beta(2010-02-23)
-Fix: Big change adjusted, working but it is very dirty ;)

v0.2 Beta(2010-01-31)
-Fix: I fixed another revision change :)
-Fix: I fixed a token change :)

v0.2 Alpha (2009-12-11)
-Fix: New Grooveshark Client Revision

v0.1 Alpha (2009-11-15)
-Initial Release


---------------LINKS-------------------------
My Website: http://www.scilor.com/
SciLor's grooveshark(tm).com Downloader Website: http://www.scilor.com/grooveshark-downloader.html
Donation: http://www.scilor.com/donate.html
-